# Parking Manager PWA

## Files
- index.html — the parking app
- manifest.json — installable PWA manifest
- sw.js — offline service worker
- icon-192.png / icon-512.png — app icons

## Install
1. Upload all files in this folder to an HTTPS static website.
2. Open the HTTPS address in Chrome on Android.
3. Use the browser menu -> Install app / Add to Home screen.
4. After the first successful load, the app shell is cached for offline use.

## Overnight rule
The app calculates the normal parking charge for the full duration.
The ₱400 overnight surcharge is added ONLY when the exit is on a later calendar date AND the exit time is 6:01 AM or later.
6:00 AM or earlier has no overnight surcharge.
